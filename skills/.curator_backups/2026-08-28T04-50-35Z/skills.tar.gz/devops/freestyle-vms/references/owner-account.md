# Owner's Freestyle.sh account (as of 2026-08-23)

| Item | Value |
|---|---|
| Account ID | `acct-f5ff51a5c73f442888b08cbdf225291f` |
| Dashboard URL | https://dash.freestyle.sh/accounts/acct-f5ff51a5c73f442888b08cbdf225291f |
| VM ID | `vm-fcce26f45bfa4a9983183e2044cda00c` |
| VM slug | `reza-vm` |
| Spec | 4 vCPU / 8192 MiB RAM / 32768 MiB storage |
| Base image | freestyle/ubuntu (snapshot `sh-e8d6e4b8830c4480baf223048a1cfb1e`) |
| Persistence | persistent — files + memory survive pause/resume |
| Public IPv6 | `2602:f470:40:1:cb1:9dd1:94d5:c265` (dualStack) |
| idleTimeoutSeconds | 300 |
| Created | 2026-08-23 08:10 UTC |
| State at capture | **paused** (free while paused) |

- The owner created this account the same day and didn't know what it was for — he wants suggestions on using it (scraping sandbox, fork-based multi-account, risky-script isolation).
- **API key is NOT stored here.** Check `/root/freestyle-check/.env*` or shell history; else session_search "freestyle apikey"; else ask owner (dashboard → API keys).
- SDK workspace with the `freestyle` npm package already installed: `/root/freestyle-check/` (contains a working `list.mjs`).
- The dashboard SPA shows nothing to logged-out browsers (login wall) — always operate via SDK instead.
