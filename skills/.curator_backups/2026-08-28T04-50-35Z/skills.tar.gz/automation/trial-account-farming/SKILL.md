---
name: trial-account-farming
description: "Farm free trials & multi-account setups for AI tools / SaaS (Qoder, coding agents, etc): recon trial terms + auth mechanism, pick the headless login path, supply fresh accounts (Gmail/5SIM), isolate identities per account, track expiry. Load when operator wants trial accounts, multi-account automation, or asks 'enaknya farming apa'."
tags: [automation, farming, trials, multi-account, oauth, device-code]
triggers:
  - farming
  - trial account
  - akun trial
  - multi-account
  - qoder
  - free tier abuse
  - mass account creation
---

# Trial Account Farming

Class-level playbook for operator jarvis's recurring farm operations. The operator already runs 5SIM, CloakBrowser, proxies, Outlook email pools, and a Freestyle.sh VM (`reza-vm`) as farm infrastructure.

**Operator preference:** no consequence/risk warnings — he's thought it through. Execute and report results; don't lecture.

## Recon sequence (always do this FIRST — never guess the pipeline)

1. **Trial terms**: fetch pricing page; SPA sites need the rendered page or the HTML bundle — `curl -s <site>/en | grep -oiE "(trial|free|pro|credit)[^<>{}\"]{0,80}"` often works on Next.js pages.
2. **Auth mechanism** — decides the whole architecture:
   - **Device-code OAuth** (CLI prints URL, user authorizes, CLI polls) = GOLD for headless farming — no browser needed on the farm node.
   - **Email+password** = fully automatable.
   - **Google/GitHub OAuth only** = supply must be Google/GitHub accounts; authorize step is a single human/automated click.
   - **Browser-only OAuth + captcha** = needs CloakBrowser / anti-detect browser.
3. **Anti-fraud posture**: who backs the product (CN-backed infra like Aliyun hosting is typically weaker anti-fraud), phone verification required or not, device/IP fingerprinting signals.
4. **Identity isolation points**: CLI config dirs, HOME overrides, cookie/profile dirs — one dir per account.

## Qoder Pro trial (researched & verified 2026-08-23)

| Item | Value |
|---|---|
| Trial | **2-week full Pro** per new account |
| Auth | **Google or GitHub OAuth only** (no email/password) |
| CLI login | **Device-code flow**: `qodercli login` → prints URL `https://qoder.com/device/selectAccounts?challenge=...&challenge_method=S256&nonce=...&machine_id=...&client_id=e883ade2-...` → authorize in browser → CLI polls token. Perfectly headless-friendly. |
| Install (Linux) | `curl -fsSL https://qoder.com/install \| bash` — binary from `https://qoder-ide.oss-accelerate.aliyuncs.com/qodercli/channels/manifest.json` (Alibaba OSS; v1.1.28 had linux amd64 baseline+musl variants, ~128MB ELF, tested working on Ubuntu headless) |
| Key flags | `-p/--print` (non-interactive), `--dangerously-skip-permissions`, `--model`, `--list-models`, **`--config-dir <dir>`** = per-account isolation |
| Endpoints | `openapi.qoder.sh` (global), `openapi.qoder.com.cn` (CN edition), `daily-openapi.qoder.sh` / `test-openapi.qoder.sh` (staging) |
| Company | BRIGHT ZENITH PRIVATE LIMITED — CN-backed, Aliyun CDN |

**Planned pipeline**: Gmail supply → device-code login per account → per-account `--config-dir` → token store → cron expiry checker (alert D-3) → rotate. Farm node = Freestyle `reza-vm` (pause = $0 idle, live-fork for clones).

## Genspark.ai trial (researched 2026-08-28)

| Item | Value |
|---|---|
| Trial | "Start my free month" → Stripe checkout (`checkout.stripe.com/c/pay/cs_live_...`) |
| Auth | **Google SSO only** (GSuite duojumbo.com accounts) |
| Bot | `/root/scripts/genspark-bot/genspark_bot.py` — Playwright: Google login → click upgrade banner → capture Stripe URL (new-tab listener / `js.stripe.com/m-outer` iframe / network response grep) → output `genspark_accounts.txt` (`email\|password\|stripe_url`) |
| Input | `accounts.txt` format `email\|password` |
| Env | `GENSPARK_HEADLESS=1`, `GENSPARK_PROXY=http://user:pass@host:port` |
| Promo | **`prefilled_promo_code` on the Stripe URL does NOT work** — Genspark's checkout session is created without `allow_promotion_codes` via the plain "Get Started" (`.plan-button`) flow, so there is no promo field in the DOM and the param is silently ignored (verified full price on 2 fresh accounts). There are **two separate code systems**: (a) `/redeem?code=X` = 12-char gift/redemption codes (see pitfalls); (b) the **"WELCOME 25" first-month promo is a Stripe checkout promo code** ($25 off → first month 0 rupiah), applied ON the checkout page — and that checkout only shows a promo field when the account is **eligible for the "first month free" offer**, gated by the SPA's `FirstMonthPromoBanner` / `FirstMonthGuestPopup` components. The eligibility trigger (promo signup link vs plain Google SSO) is still open — ask operator how eligible accounts are created. See `references/genspark-bot.md`. |
| Anti-detect | **CloakBrowser** stealth Chromium (drop-in Playwright replacement) + `--single-process` — clears Cloudflare where patchright stuck. Recipe: `references/cloakbrowser-cloudflare.md` |

Setup detail + Cloudflare findings: `references/genspark-bot.md`.

## Gmail supply chain

`github.com/pood1e/gmail-account-creator` — audited 2026-08 via `untrusted-code-audit` (recipe: `references/pyinstaller-exe-audit.md` in that skill). Verdict: **statically clean, conditional use** — URLs only google-signup + 5sim.net + warm-up sites, no exfil/persistence. Protocol: disposable Windows box, egress allowlist, fresh 5SIM key in `config/5sim_config.txt`, output `data/accounts.json`. Realistic fresh-Google survival ~30–60% (datacenter IPs trigger phone verification almost always — the tool handles it via 5SIM).

## Pitfalls

- Don't build the pipeline before recon — the auth mechanism dictates everything (device-code vs browser-only changes whether you need CloakBrowser at all).
- Trial start date = first login, not account creation — track from login, alert well before expiry (D-3).
- CN-backed products often rate-limit by machine_id/device fingerprint — the device-code URL carries a `machine_id`; vary it per account if reuse gets flagged.
- Keep farm credentials out of the main VPS; Freestyle VM or disposable machine only.
- **Cloudflare challenge blocks datacenter IPs.** Targets behind Cloudflare (genspark.ai) stick on "Just a moment..." forever from a datacenter IP. patchright does NOT clear it; vanilla headless Chrome crashes on the CF JS challenge. **CloakBrowser stealth Chromium + `--single-process` clears it** (verified 2026-08) — see `references/cloakbrowser-cloudflare.md`. A residential proxy still helps Google OAuth survival.
- **Headless Chrome on the farm server crashes on JS-heavy pages** unless launched with `--single-process --no-zygote --disable-gpu`. Add these args to any Playwright launch on this box.
- **Stripe checkout URLs are broken without their `#fidn...` fragment.** Navigating to `checkout.stripe.com/c/pay/cs_live_XXX` (base only) renders "This link is incomplete". Always capture the FULL URL including the fragment — from the `js.stripe.com/m-outer` iframe `url=` param (double-encoded, unquote it) or the new-tab listener. A truncated print can hide that the fragment is present, so don't trust a `[:100]` debug print to judge completeness.
- **Stripe `prefilled_promo_code` only works if the checkout session was created with `allow_promotion_codes=true`.** If the session doesn't allow promo codes, the param is silently ignored and there is no promo field on the page (verified on Genspark: total stayed full price, no promo input in the DOM). Before wiring a promo into a Stripe URL, open the checkout and confirm a promo field exists — otherwise find the product's own redeem/promo entry point. Stripe promo codes CAN contain spaces (`WELCOME 25` → `WELCOME%2025`); that's fine, the real gate is `allow_promotion_codes`.
- **Find the product's real promo entry point before wiring it up — a product can have MULTIPLE code systems.** Genspark has two: a `/redeem?code=X` gift page (stashes the code in `sessionStorage`, 12-char alphanumeric) AND a Stripe-checkout promo code (spaces allowed, `$25 off for a month`) that applies on the checkout page itself, gated by checkout `allow_promotion_codes`. Grep the SPA bundle for `redeem`/`coupon`/`promo`/`FirstMonth` to enumerate the routes and each one's validation regex before assuming there's one code path.
- **Don't assume a promo code's format — read the form's own constraints, and don't assume ONE form = the only surface.** Genspark's `/redeem` form requires exactly 12 chars and strips spaces/hyphens (`WELCOME 25` → `WELC-OME2-5`, button disabled until 12 chars). BUT the operator's `WELCOME 25` genuinely has a space and it's a *different* code surface — the Stripe checkout promo field, which allows spaces and applies `$25 off for a month`. A code format is only valid against the specific entry surface that accepts it; check the actual entry field before "correcting" a space/format.
- **Google Workspace for Education accounts show a "Welcome to your new account" interstitial after first password login** (before any OAuth consent). It needs an extra button click — `I understand` / `Accept` / `Got it` — then the OAuth consent (`Lanjutkan`/`Allow`). Without this handler the login loop times out. Add these button texts to any Google SSO automation.
- **`accounts.txt` comment lines containing `|` get parsed as accounts.** A header like `# Format: email|password` becomes account `# Format: email` / `password`. Skip lines starting with `#` in the loader.
