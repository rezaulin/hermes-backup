---
name: simmubtadiat-development
description: Develop, migrate & deploy SIM Mubtadiat (pesantren management app) at /opt/simmubtadiat — Go/chi/pgx backend, Vite multi-page frontend, Docker Compose + Postgres 15, Hijri academic calendar. Load for any work on reviewtechno.me, the pesantren app, its database, or its deploy.
---

# SIM Mubtadiat Development

Pesantren management app (santri, pengajar, penilaian, absensi). Owner: jarvis. Live at https://reviewtechno.me (nginx → 127.0.0.1:8080). Repo: git@github.com:rezaulin/simmubtadiat.git (SSH key works, push from server).

## Stack & layout
- Backend: Go (chi router, pgx/v5). `main.go` = routes; `models/` = data layer; `handlers/` = HTTP.
- Frontend: Vite multi-page — entries in `frontend/*.html`, logic in `frontend/src/js/*.js`, builds to `public/dist`.
- Deploy: Docker Compose in /opt/simmubtadiat. Containers: `simmubtadiat-app-1` (port 8080), `simmubtadiat-db-1` (postgres:15).

## Editing gotchas
- **Go AND frontend JS files use CRLF endings.** The `patch` tool's fuzzy matching often fails on multi-hunk CRLF patches; fall back to Python `str.replace`, reading/writing with `newline=""` to preserve CRLF. When patching JS via execute_code with multiple old/new pairs, verify each one actually matched — a batch of LF-normalized old_strings can silently match nothing against a CRLF file (check "patched:" vs "NOT FOUND" output before writing).
- `go build ./...` fails with PRE-EXISTING errors in `scripts/` and `tmp/` (duplicate mains, stale APIs) — noise. Build only the app: `go build -o /tmp/test .`
- Frontend JS is plain ESM, one module per page (`<script src="./src/js/x.js" type="module">`).

## Database
- Access: `docker exec simmubtadiat-db-1 psql -U mubtadiaat -d mubtadiaat_db` (creds from /opt/simmubtadiat/.env; never print DB_PASS).
- Migrations: numbered `migrations/NNN_name.sql`, idempotent (IF NOT EXISTS / ON CONFLICT), auto-run on container start by `./migrate-runner migrations`. Add the next number; never edit applied migrations.

## Domain model (academic calendar)
- `tahun_ajaran` e.g. '2026/2027'; `tahun_hijri` e.g. 1447. Active values in `settings` table via GET/PUT `/api/settings/umum`. **`tahun_hijri_aktif` is a PAIR string** like `1447/1448` — one tahun ajaran spans two Hijri years (owner rule: "1 tahun ajaran ada 2, kayak Masehi 2025/2026, begitu juga Hijriyah 1447/1448"). Any `parseInt`/numeric-input binding must handle the slash first; rekap.js prefills only on `/^\d+$/`, settings.js calendar prefill uses the second (running) year, so users never switch year settings mid-year. Month dropdown options are RANGE-DRIVEN (owner correction 2026-08): `loadKalenderRange()` fetches the saved semester ranges first, and the dropdown lists ONLY months from Smt-1 start month through Smt-2 end month (e.g. 11 months for TA 2026/2027), with the 24-month pair list only as fallback when no calendar exists for the active TA.
- `kalender_semester_hijri`: Semester 1 & 2 ranges entered in HIJRI dates (tgl/bulan/tahun). Frontend computes Gregorian equivalents (`masehi_mulai/selesai`) via Intl islamic-umalqura before saving. See references/hijri-calendar.md.
- `kalender_kuartal`: derived sync table (kwartal 1–4 per tahun_ajaran) consumed by absensi-sesi lock & rekap; rebuilt automatically on semester save.
- Absensi sesi (per-date, Masehi): semester resolved by kalender_kuartal range lookup.
- Absensi manual bulanan (per Hijri month): `semester` column resolved by month OVERLAP with the semester range (`SemesterDariBulanHijri`, since 2026-08 — the old day-15 heuristic silently dropped months whose semester starts mid-month, e.g. Smt 1 beginning 17 Syawal lost all of Syawal); backfilled on every calendar save. Stray/out-of-range rows: see sim-mubtadiat references/academic-domain-model.md → "Forcing stray manual-attendance rows" before deleting or ignoring them — they are often Hijri-year typos the owner wants force-corrected.
- Penilaian: kuartal 1/3 = Tamrin, 2/4 = Ujian; semester lock via `penilaian_status`.

## Debugging gotchas (production)
- **App logs do NOT show SQL error text for a failed POST** — `docker logs simmubtadiat-app-1` only shows the request line + 500. To find the cause, grep the access log for 5xx on the endpoint (`grep -i "hijri-semester" | grep 500`), then **reproduce the SQL directly**: run the transaction's statements step by step via `docker exec -i simmubtadiat-db-1 psql -U mubtadiaat -d mubtadiaat_db -v ON_ERROR_STOP=1 <<'EOF' ... EOF` (BEGIN → each statement → ROLLBACK). The failing statement names itself.
- **LATERAL/subquery alias pitfall (real bug, 2026-08):** in the kalender_kuartal sync query the SELECT used `k.tahun_ajaran` while `k` was only the LATERAL `(kuartal, idx)` value list — the column lived in the subquery alias `base` → 500 on every calendar save. Rule: when writing multi-alias Postgres SQL inside a Go tx, run the FULL SQL in psql first with sample data BEFORE building + deploying, not after.
- **"Same value shows in two UI sections" bug pattern (2026-08):** user saw one izin count in BOTH raport semester sections. Cause was not data — the backend returned one annual aggregate map and the frontend rendered it N times. Diagnose by grepping the frontend render calls for a shared map variable passed to multiple section-renderers; fix by returning per-section aggregates from the backend and passing the right slice to each section.
- **Vision tool may be unavailable** (provider error on vision_analyze). OCR fallback: `tesseract /root/.hermes/cache/images/<img>.jpg stdout -l ind+eng`. Good enough to read settings-page values from user screenshots (it misses small digits sometimes — cross-check against DB).
- **Verify UI claims before stating them (owner caught this, 2026-08):** agent told the user "klik tombol Generate Khos" — no such button exists; the generate endpoints (`/api/penilaian/generate-khos`, `/generate-bayan`, `/generate-am`) are called INSIDE `saveAll()` (the "Simpan Semua" button) in frontend/src/js/penilaian.js. Owner challenged: "Emang ada tombol generate khos?" Before telling the user to click/enter anything, grep the page's HTML + JS for the element (`grep -n "generate" frontend/penilaian.html frontend/src/js/penilaian.js`). The real recalc path: Penilaian → pick bagian → Simpan Semua (see also: stored scores are snapshots — logic fixes don't retroactively update nilai_khos/nilai_bayan rows; mechanics + audit checklist in skill `sim-mubtadiat` references/academic-domain-model.md → "Recalculating stored scores").
- **"Corrections don't work / nilai hilang" is often stale scores from pindah bagian, not a logic bug (2026-08):** santri who change bagian/class leave orphaned score rows — duplicate `nilai_bayan` (unique key includes bagian_id) and `nilai_khos`/`nilai_kuartal` still bound to the OLD class's mapel while regen reads the CURRENT class's mapel. Also: absence-based Akhlaq corrections are a SILENT no-op if no mapel has kategori `akhlaq_perilaku` (prod shipped with none). Audit queries + owner-approved cleanup recipe: skill `sim-mubtadiat` references/academic-domain-model.md → "Stale & duplicate scores after pindah" and the corrections table. Root `nilai_kuartal` staleness is a data-ownership question — STOP and ask the owner (mid-TA class change vs migration artifact) before relinking/deleting raw marks.
- **Background processes run under /bin/sh, not bash** — `source .env` fails with exit 127 (`source: not found`). In backgrounded terminal commands, load env POSIX-style instead: `export $(grep -E '^(DB_USER|DB_PASS|DB_PORT|DB_NAME)=' .env | xargs)`.
- **Proving business logic end-to-end — `go test` is unusable in this repo:** stale test files in `models/` (alumni_koersi_test, pencarian_pengabdian_test, perpindahan_test, santri_khidmah_test) fail to COMPILE with outdated signatures, so any `go test ./models/` dies before running. Do NOT fix those as part of a feature. Instead write a **standalone runtime verifier**: a tiny `main` package (working example: `/opt/simmubtadiat/tmp_verify_koreksi/main.go`) that imports `github.com/mubtadiaat/app/{config,models}`, sets `config.DB` to a pgxpool, seeds synthetic rows under a fake tahun ajaran (e.g. `'2099/2100'` — never collides with real data), calls the REAL model functions (`GenerateNilaiKhos`, `GenerateAlBayan`, …), asserts expected values with PASS/FAIL prints, and `defer`s full cleanup (delete by synthetic IDs, FK-safe order). Run it: `DB_IP=$(docker inspect simmubtadiat-db-1 --format '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}')`, then `set -a; source .env; set +a; DB_HOST=$DB_IP go run ./tmp_verify_koreksi` — the DB port is NOT exposed to the host, so `DB_HOST` must point at the container IP. This is the accepted way to answer "does this logic actually work?" with proof, not code-reading. Owner values this — he asks "apakah code untuk itu sudah berfungsi?" expecting verification, not reassurance.
  - **TEST-ORDERING PITFALL (hit 2026-08):** tests in one verifier share the seeded rows, so a test that MUTATES the fixture (e.g. TEST4 raised all kuartal scores + deleted absensi to test clamping) silently invalidates every later test's expectations — got a false "TEST3 FAIL" because TEST4 ran before it in the reordered file. Rule: order tests so read-only / additive-fixture tests run before mutating ones, or re-seed between tests. A surprising FAIL right after reordering verifier code → suspect ordering, not the app logic.

## Feature workflow
1. Explore: grep `models/ handlers/ main.go`; inspect DB state before designing (counts + `\d table`).
2. Commit + push current state first — backup habit the owner expects.
3. Code in order: migration → model → handler → route (main.go) → frontend HTML + JS.
4. Verify locally: `go build -o /tmp/test .`; `node --check` for JS.
5. Commit + push with descriptive message.
6. Deploy (background, takes minutes): `docker compose build app && docker compose up -d app`.
7. Verify: logs show `Migrasi diterapkan: NNN_...`; `curl https://reviewtechno.me/api/health`; new endpoint returns 401 without token = route alive; grep container `public/dist` for new element IDs.

## Owner preferences for this app
- **Hijri-first**: santri/pengajar-facing dates entered in Hijri; Masehi is internal plumbing.
- **Consolidated menus**: one card/form beats multiple fragmented sections — owner rejected a split "kuartal dates + month mapping" UI for a single "Kalender Akademik" card with Hijri semester ranges.
- **Selectors derive from saved config**: when the owner has already configured a range/period (semester start–end), pickers must offer ONLY values inside it. Owner rejected a 24-month dropdown when the calendar spans 11 months: "kan kita udah setting waktu mulai semester dan selesai semester". Don't hardcode exhaustive option lists when a configured range exists.
- **Set once, never fiddle**: settings that span the whole tahun ajaran (like the Hijri year pair) must be entered once and never require switching mid-year ("tidak perlu gonta ganti").
- **Owner iterates**: may approve an option then refine it. Show the simplest unified shape early instead of overbuilding the first proposal.
