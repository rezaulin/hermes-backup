---
name: sim-mubtadiat
description: Operate and develop SIM Mubtadiat — Go + PostgreSQL pesantren management app in Docker at /opt/simmubtadiat, served via nginx/Cloudflare at reviewtechno.me. Load for ANY work on this app — status checks, bug fixes, feature additions, DB queries, backups, deployments. Covers stack layout, health-check commands, DB access, code map, academic domain model (kuartal/semester/absensi/penilaian), and project gotchas.
---

# SIM Mubtadiat — Pesantren Management App

Recurring project of user jarvis. ALWAYS load this before touching `/opt/simmubtadiat`.
Domain-model deep dive (kuartal/semester/absensi/penilaian): see `references/academic-domain-model.md`.
Sibling skill `simmubtadiat-development` (projects/) covers the same app — feature workflow, deploy steps, and **production debugging gotchas** (500s with no SQL error text in logs → reproduce SQL in psql; OCR fallback via tesseract when vision tool is down). The two skills overlap and are candidates for consolidation.

## Stack & locations

| Item | Value |
|---|---|
| Code | `/opt/simmubtadiat` (Go backend + vanilla-JS frontend in `frontend/src/js/`) |
| Runtime | Docker compose: `simmubtadiat-app-1` (port 8080, bound to 127.0.0.1) + `simmubtadiat-db-1` (postgres:15-alpine) |
| Public URL | `https://reviewtechno.me` (nginx → 8080, behind Cloudflare) |
| Server IP | 43.156.230.10 (app also answers direct IP requests) |
| DB creds | `/opt/simmubtadiat/.env` — `DB_USER=mubtadiaat`, `DB_NAME=mubtadiaat_db` (never print DB_PASS) |
| Git | `git@github.com:rezaulin/simmubtadiat.git` — SSH key on server works. Verify sync: `git ls-remote origin` vs `git rev-parse HEAD` |

## Health check (fast triage)

```bash
docker ps -a --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'
curl -s -o /dev/null -w 'GET / -> %{http_code} %{time_total}s\n' https://reviewtechno.me/
curl -s https://reviewtechno.me/api/health   # returns "OK"
docker logs simmubtadiat-app-1 --tail 20
```

## DB access (inside container)

```bash
docker exec simmubtadiat-db-1 psql -U mubtadiaat -d mubtadiaat_db -c "..."
```

## Gotchas

- `HEAD /` returns **405 (allow: GET)** — the Go router only allows GET on `/`. This is NORMAL, not an outage. Use GET for checks.
- If `kalender_kuartal` table is EMPTY, attendance input silently skips rekap/semester binding (lookup finds no kuartal → no lock check, no rekap recalc). Always check calendar rows before debugging attendance/penilaian: `SELECT * FROM kalender_kuartal ORDER BY tahun_ajaran, kuartal;`
- Absensi → semester mapping is DATE-DRIVEN via `kalender_kuartal`, never a manual pick. Changing calendar dates retroactively changes which semester past attendance belongs to; consider backfill/recalc.
- `tmp_extract/` and `tmp_deploy_folder/` contain stale duplicate copies of code — grep results there are noise; exclude with `grep -v tmp_extract` / `tmp_deploy`.
- `tmp_batch_regen/` and `tmp_verify_koreksi/` are throwaway Go verification scripts kept INTENTIONALLY untracked (owner decision 2026-08: "biarkan saja dulu"). Do NOT delete or gitignore them — they're the working recipe for batch regen & live correction verification against the production DB (see references/academic-domain-model.md → Recalculating stored scores).
- **Built frontend assets exist ONLY inside the container** at `/app/public/dist/assets/` — Vite builds during the Docker multi-stage image build; there is NO `frontend/dist/` on the host. Verify deployed frontend changes with `docker exec simmubtadiat-app-1 sh -c 'ls /app/public/dist/assets/ | grep <page>'`. Vite MINIFIES function names, so grepping a bundle for a source-level name (e.g. `clampNilaiInput`) returns 0 even when the code is deployed — verify via CSS class names, data-attributes, or logic fragments (e.g. `.max!==""?parseFloat`).
- **Verifying served assets through Cloudflare:** download to a temp file first (`curl -s URL -o /tmp/x && grep -c pat /tmp/x`) and md5-compare against the container copy (`docker exec simmubtadiat-app-1 md5sum /app/public/dist/assets/<file>`) — piping curl output into grep produced false zeros in practice. If md5 matches, the file IS served correctly; `cf-cache-status: HIT` on hashed asset filenames is fine (hash changes every build, so HIT still serves the new file). After a frontend change, tell the owner to Ctrl+F5 once (hashed filenames then make caching self-managing).
- Before risky feature changes: SQL backups already exist in `/root/backup_*.sql`; take a fresh one (`docker exec simmubtadiat-db-1 pg_dump -U mubtadiaat mubtadiaat_db > /root/backup_<date>.sql`) and commit code to GitHub first.
- **Akhlaq absence-corrections are a silent no-op unless mapel kategori exists**: `GenerateNilaiKhos` only applies izin/alpha corrections to mapel with `kategori='akhlaq_perilaku'`. Production DB originally had ZERO such mapel (all أخلاق mapel were `umum`) → corrections never fired despite the code being correct. Owner rule (2026-08, chose option A): ONLY mapel named **الأخلاق** get `akhlaq_perilaku`; **علم الأخلاق** (kitab) stays `umum`. PITFALL when updating by Arabic name: exact `nama_mapel = 'الأخلاق'` matched only 4/10 rows due to Unicode variants (LENGTH 7 vs 8 — different hamza forms render identically). Use `WHERE nama_mapel ILIKE '%أخلاق%' AND nama_mapel NOT ILIKE '%علم%'` and verify COUNT + LENGTH afterwards. Full detail: references/academic-domain-model.md → corrections section.
- **Santri pindah bagian/naik kelas creates stale + duplicate scores** (RESOLVED pattern, 2026-08 — option A + option-2 dedupe): `nilai_bayan` duplicates USED to come from the unique key including `bagian_id`; **migration 048 (2026-08) changed the unique key to `(santri_id, tahun_ajaran)`** so duplicates are now structurally impossible (dedupe DELETE of rows whose bagian_id ≠ current was run as part of the migration). Upserts in penilaian_dasar.go/penilaian_final.go conflict on `(santri_id, tahun_ajaran)`. `nilai_kuartal` stay linked to OLD-class mapel and must STAY there (owner rule) — instead `GenerateNilaiKhos` + raport query were widened to include any mapel the santri has kuartal scores in (OR EXISTS clause), and duplicate-input santri (scores in two classes, same TA) get ALL old-class mapel ignored whenever they have ANY score in the current class. **Name-based dedupe failed in production** (Arabic mapel names have Unicode/spaces variants — `التاريخ` 7 vs 8 chars, `علم الصرف` 3 variants, `علم  النحو` double space) and left old-class khos rows dragging the Bayan Asli average down (8 instead of 9 for MAGFIROH/MAHYA/NASYWA/RIA). Final rule (commit after 0b2dfc5): `NOT EXISTS (any nilai_kuartal in current class) AND EXISTS (nilai_kuartal in this old-class mapel)` — old class only counts when the current class is completely empty for that santri. When a santri's Khos/Bayan looks empty or corrections "don't work", audit stale rows FIRST. Full evolution + diagnostic SQL: references/academic-domain-model.md → "Stale & duplicate scores after pindah".
- **Backend compile check**: use `go build -o /tmp/simtest .` (main package only). `go build ./...` FAILS on pre-existing broken packages (`scripts/`, `tmp/`, test files with stale signatures) that are NOT part of the deployed app — these errors are noise, do not "fix" them as part of a feature.
- **Source files use CRLF line endings.** When using the patch tool on models/handlers, hunk matching can misfire. Especially `SaveAbsensiManualBulanan` (santri) and `SaveAbsensiManualPengajarBulanan` (pengajar) are near-identical — a patch meant for one landed on the other once. Always include enough unique surrounding context (e.g. the enclosing function signature) and re-read the file after patching.
- **Multi-line SQL for psql: write to a file, then pipe.** `docker exec -i simmubtadiat-db-1 psql -U mubtadiaat -d mubtadiaat_db -v ON_ERROR_STOP=1 < /tmp/x.sql` (or `cat /tmp/x.sql | docker exec -i ...`). Inline heredocs with SQL that happens to contain `&` (e.g. in comments/strings) trigger a false "backgrounding detected" rejection in the terminal tool. For short one-liners, `psql -c "..."` is fine.

## Code map

- `main.go` — chi router, route groups (`/api/kalender`, etc.). Calendar routes: GET open to all except wali_santri; POST (save kalender + hijri-semester mapping) admin/pimpinan-only.
- `models/` — DB layer. Key files: `kalender.go` (kuartal calendar CRUD), `absensi.go` (session attendance + rekap recalc), `absensi_manual.go` (Hijri-monthly manual attendance — santri & pengajar, both structs + save fns nearly identical, see patch pitfall), `hijri_semester.go` (Hijri academic calendar: semester CRUD, `SemesterDariBulanHijri` month-OVERLAP resolution — the day-15 heuristic was replaced 2026-08 because it dropped months whose semester starts mid-month (Smt 1 starting 17 Syawal lost all of Syawal); auto-backfill of manual attendance on every calendar save), `penilaian_dasar.go` / `penilaian_final.go` (Khos / Nilai 'Am / Al-Bayan — per-semester vs annual attendance consumption table in references/academic-domain-model.md), `penilaian_lock.go` (`SemesterDariKuartal`, semester lock), `handlers/mapel.go` (aktif_kuartal validation), `settings_general.go` (`GetTahunAjaranAktif`, `tahun_hijri_aktif` — stored as a PAIR string like `1447/1448` since one tahun ajaran spans two Hijri years; see references/academic-domain-model.md "Tahun Hijri aktif is a PAIR" before parsing it)
- `handlers/` — HTTP handlers (one file per domain). Includes `data_health.go` (`GET /api/data-health`, pimpinan/admin only — in-app watchdog, see below).
- `models/data_health.go` — **Data health watchdog** (2026-08): `GetDataHealthReport(ctx, ta)` runs 4 anomaly checks (stale old-class khos, active santri without Al-Bayan, NULL-semester manual attendance, kuartal scores spanning >1 class) → rendered as a dashboard widget on `index.html` (`#dash-data-health` + `loadDataHealth()` in main.js; merah = butuh tindakan, kuning = perhatian, hijau kecil = bersih). **Owner preference (2026-08): monitoring notifications live in-app on the pimpinan dashboard — NOT Telegram cron jobs.** Interpretation gotchas: `bayan_kosong` is LEGITIMATE when only kuartal-1 scores are entered (Khos needs the ujian kuartal) and `nilai_dobel_kelas` is informational (archive handled by option-A rule) — don't panic-fix these two.
- `frontend/src/js/` — vanilla JS per page: `settings.js` (calendar admin UI + Hijri→semester mapping UI card), `absensi.js`, `absensi-manual.js`, `rapot.js`, `rekap.js`, etc. `penilaian.js` renders the spreadsheet (renderSection kuartal tables, renderRaportSection per-semester, renderBayanSection) and carries owner-confirmed scoring-UI rules (2026-08, see references/academic-domain-model.md → "Penilaian UI rules"): nilai < 5 (4 & 4.5) marked red live (number + cell background + student NAME via `.nilai-rendah`/`.nama-rendah`, CSS in `frontend/style.css`), kuartal inputs clamped real-time to category caps (umum 10 / Quran+Akhlaq 8, `maxNilaiKuartal` in models/penilaian_dasar.go) incl. Excel-paste path, and student NAME turns red/amber when attendance already cuts/will cut a score (`.nama-rendah`/`.nama-warning`, `alasanAbsensi` + thresholds `ABSENSI_AMBANG`; red = ≥ threshold and cutting, amber = ≥75% of threshold "hampir kena"; tooltip on the name, combined with low-score reason). Do not remove these mark classes when refactoring the tables. Frontend is multi-page Vite: a NEW page must be registered in `frontend/vite.config.js` `rollupOptions.input` and have its own `.html` entry.
- `frontend/src/js/xss.js` — despite the name, also hosts GLOBAL utilities: the global-search modal + `/api/search` result rendering (`searchBadgeFor` maps tipe→href/badge; `fetchSearchResults`), the `BOTTOM_NAV` role configs + `renderBottomNav(role)` (mobile bottom nav — renderer inserts the FAB spacer after item index 2, so keep role navs at 4 items for the default 4-slot+spacer layout), and the PWA install banner. Per-page sidebar allowlists are the inline `MENU_ACCESS`-style role objects in each page's HTML (`pimpinan: [...]`, `muroqib: [...]`, ...).
- `models/pencarian.go` — `GlobalSearch` sources: santri aktif/pengabdian, alumni (= santri status lulus/boyong/keluar, which IS the arsip content), pengajar (`is_active=true`), dewan_harian. **Pengajar purna is NOT a search source (known gap, owner-reported).** Role gating: global santri search for pimpinan/admin/keamanan/mufatish; alumni search for pimpinan/admin/keamanan. Pengajar purna page also lacks a read-only Detail view (only admin Edit/Hapus) — known gap.
- `migrations/NNN_name.sql` — numbered SQL migrations, run automatically on container start by `docker-entrypoint.sh` → `./migrate-runner migrations` (built from `scripts/migrate-all`). Keep migrations idempotent (IF NOT EXISTS / ON CONFLICT).

## Workflow

1. Health-check + git-sync verify before editing (see above).
2. **Custom feature/UI requests: discuss BEFORE implementing.** Owner pattern (2026-08, e.g. "Kita diskusi dulu"): audit the current state first, then present (a) what already exists, (b) concrete options/defaults, (c) 2–4 targeted decision questions. Wait for the numbered answers, THEN implement. Owner decides by picking options and answering questions — never by reading a design doc.
3. Read the relevant model file first — business rules are documented in Indonesian comments above each function.
4. Verify backend compiles with the MAIN package only: `go build -o /tmp/simtest .` — NOT `go build ./...` (see gotchas).
5. Deploy: `docker compose up -d --build app` in `/opt/simmubtadiat` (multi-stage: Vite frontend + Go; slow on this small VPS — run in background with notify_on_complete=true). Migrations auto-run on start. Verify with health check + `docker logs`.
6. Commit & push to GitHub after each working change.

## Mobile / responsive-UI patterns (owner cares deeply about the phone experience)

The app is a PWA used heavily on phones; desktop breakpoint is `md:` (768px). Reusable patterns — when owner says "rapikan tampilan HP", diagnose against these BEFORE inventing new markup:

- **Table → card transformation**: a table gets class `table-responsive` AND every `<td>` a `data-label="..."` attribute; `frontend/style.css` then renders each cell as a label:value row on mobile (CSS `content: attr(data-label)`). Pages done RIGHT this way: `alumni.html`, `santri.html`, `pengajar-purna.html`. Pages MISSING it (tables scroll sideways on phones): `pengajar.html` (3 tables incl. the main list + mufatish/mustahiq), `catatan.html`. To "disamakan dengan tampilan alumni": add `table-responsive` to the `<table>` + `data-label` to each `<td>` in BOTH the HTML template and the JS `renderTable` innerHTML.
- **Horizontal tab rows on mobile** (e.g. profil-santri Biodata/Riwayat/Pelanggaran are `flex space-x-6` inside `overflow-x-auto`): owner wants them STACKED on phones → wrap nav in `flex flex-col md:flex-row` (keep side-by-side on desktop).
- **Bottom nav is JS-driven** per role (`BOTTOM_NAV` in xss.js) — static `<nav>` markup in the HTML is the default fallback only; changes to a role's nav must go through `BOTTOM_NAV`. Owner 2026-08 direction for muroqib: narrow it to Santri | Absen | Pelanggaran (4 slots incl. spacer + FAB) — Beranda still reachable via the mobile top header.
- Sticky first columns in tables use `sticky left-0 ... z-10` — keep the bg classes when touching those cells or they become transparent-over-content.

## Workflow

